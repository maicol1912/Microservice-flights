export const USER = { name: 'users' };
export const PASSENGER = { name: 'passengers' };
export const FLIGHT = { name: 'flights' };
